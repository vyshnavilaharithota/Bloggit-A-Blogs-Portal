<?php echo e($slot); ?>

<?php /**PATH C:\Users\karth\Desktop\desktop 10-12\Bloggit\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
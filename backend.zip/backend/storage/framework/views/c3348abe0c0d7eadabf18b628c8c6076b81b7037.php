<?php $__env->startComponent('mail::message'); ?>


Bloggit

Click on the link given below to reset your password

<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:4200/forgotPassword?token='.$token->token]); ?>
Reset Password
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
Bloggit
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\karth\Desktop\desktop 10-12\Bloggit\backend\resources\views/Email/passwordReset.blade.php ENDPATH**/ ?>